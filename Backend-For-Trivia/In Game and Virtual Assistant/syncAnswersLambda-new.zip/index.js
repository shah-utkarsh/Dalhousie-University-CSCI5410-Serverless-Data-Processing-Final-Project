const AWS = require('aws-sdk');

const ENDPOINT = 'qx114ctsrj.execute-api.us-east-1.amazonaws.com/production';
const client = new AWS.ApiGatewayManagementApi({ endpoint: ENDPOINT });
const connections = [];
const connectionToTeamMap = {}; // To store the mapping between connection IDs and team IDs

const sendToAll = async (connections, requestBody, currentConnection) => {
try {
    const promises = connections.map(async (connectionId) => {
      // Skip sending the message to the currentConnection
      if (connectionId !== currentConnection) {
        await client.postToConnection({
          ConnectionId: connectionId,
          Data: JSON.stringify(requestBody),
        }).promise();
        console.log(`Message sent to WebSocket connection ${connectionId}`);
      }
    });

    await Promise.all(promises);

    console.log('All messages sent to WebSocket connections except currentConnection');
  } catch (error) {
    console.error('Error occurred:', error);
  }
};

// Function to send a message to all connections associated with a specific team
const sendToTeam = async (requestBody, currentConnection) => {
  const currentTeamID = connectionToTeamMap[currentConnection];
  const matchingConnections = Object.entries(connectionToTeamMap).filter(([connectionId, teamId]) => teamId === currentTeamID).map(([connectionId]) => connectionId);
  await sendToAll(matchingConnections, requestBody, currentConnection);
};

exports.handler = async (event, context) => {
  console.log(event);
  if (!event.requestContext) {
    return { "message": "No context" };
  }
  const connectionId = event.requestContext.connectionId;
  const routeKey = event.requestContext.routeKey;

  switch (routeKey) {
    case '$connect':
      connections.push(connectionId);
      break;
    case 'setTeam':
      if (event.body && event.body.trim() !== '') {
        const bodyObject = JSON.parse(event.body);
        const teamId = bodyObject.team;
        if (teamId) {
          connectionToTeamMap[connectionId] = teamId;
        }
      }
      break;
    case '$disconnect':
    const index = connections.indexOf(connectionId);
      if (index !== -1) {
        connections.splice(index, 1);
      }
      console.log("Removed connection: ", connections);
      break;
    case 'sync':     
      const requestBody = JSON.parse(event.body);
      // await sendToAll(connections, requestBody, connectionId);
      await sendToTeam(requestBody, connectionId);
      break;
    case 'hint':
      const body = JSON.parse(event.body);
      await sendToTeam(body, connectionId);
      break;
    case '$default':
      console.log("in default"); 
      break;
    default:
      console.log("Default!");
      break;


  }
  
  return {
    statusCode: "200",
    body: JSON.stringify("Hello from lambda")
  };

};
