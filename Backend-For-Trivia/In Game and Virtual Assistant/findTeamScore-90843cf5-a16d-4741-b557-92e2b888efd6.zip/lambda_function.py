import os
import sys
import subprocess
subprocess.call('pip install firebase_admin -t /tmp/ --no-cache-dir'.split(), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
sys.path.insert(1, '/tmp/')
import firebase_admin
from firebase_admin import credentials, firestore

cred = credentials.Certificate("./credentials.json")
firebase_admin.initialize_app(cred)
db = firestore.client()

def lambda_handler(event, context):
    print("Request EVENT :: ", event)
    session_state = event["sessionState"]
    slots = session_state["intent"]["slots"]
    intent = session_state["intent"]["name"]

    teamID = slots.get("TeamName")
    
    print("event['invocationSource'] :: ", event['invocationSource'])

    if event['invocationSource'] == 'DialogCodeHook':
        if not teamID:
            response = {
                "sessionState": {
                    "dialogAction": {
                        "type": "ElicitSlot",
                        "slotToElicit": "TeamName",
                    },
                    "intent": {
                        'name': intent,
                        'slots': slots
                    }
                }
            }
        else:
            response = {
                "sessionState": {
                    "dialogAction": {
                        "type": "Delegate",
                    },
                    "intent": {
                        'name': intent,
                        'slots': slots
                    }
                }
            }
            
    if event['invocationSource'] == 'FulfillmentCodeHook':
        # teamScore = 1880
        score = 0
        response_message = ""
        try:
            print("TEST 1")
            teamID_interpretedValue = slots.get("TeamName", {}).get("value", {}).get("interpretedValue", "")  
            subcollection_ref = db.collection("quizPlayed").document(teamID_interpretedValue).collection("teamQuiz")
            query_snapshot = subcollection_ref.get()
            print("TEST 2")
            for doc in query_snapshot:
                print("TEST 2.1 doc:: ", doc)
                data = doc.to_dict()
                correct_count = data.get("correctCount", 0)
                score += correct_count
            
            print("TEST 3: ", len(query_snapshot))
            if len(query_snapshot) > 0:
                response_message = f"Score for {teamID_interpretedValue} is {score*10}"
            else:
                response_message = f"Sorry, no data found for {teamID_interpretedValue} in the database."
        
        except Exception as e:
            error_type = type(e).__name__  # Get the exception type
            error_message = str(e)  # Get the exception message
            error_detail = {"errorType": error_type, "errorMessage": error_message}  # Create the error details dictionary

            print("Exception occurred:", error_detail)  # Print the exception details
            response_message = "An error occurred while querying the database."
        

        response = {
            "sessionState" : {
                "dialogAction" : {
                    "type" : "Close"
                },
                "intent" : {
                    'name':intent,
                    'slots' : slots,
                    'state': 'Fulfilled'
                }
            },
            "messages" : [
                {
                    "contentType" : "PlainText",
                    "content": response_message
                }
            ]
        }

    print("response", response)
    return response
